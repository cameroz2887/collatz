#!/usr/bin/env python3
# collatz_verify.py | Exhaustive check for 2 ≤ n < 1174

def collatz(n: int) -> bool:
    """
    Returns True if the Collatz orbit of n reaches 1
    under the (3n+1)/2 and n/2 rules.
    """
    while n != 1:
        if n % 2 == 0:
            n //= 2
        else:
            n = (3 * n + 1) // 2  # integer division
    return True

if __name__ == "__main__":
    for n in range(2, 1174):
        assert collatz(n), f"Failed at n={n}"
    print("All 2 ≤ n < 1174 converge to 1.")
