# Collatz Verification Script

This Python script verifies that all integers from 2 to 1173 converge to 1 under the modified Collatz map:

- If n is even: n → n / 2
- If n is odd: n → (3n + 1) / 2

## Usage

No dependencies are required. To run:

```bash
python3 collatz_verify.py
```

## Output

```
All 2 ≤ n < 1174 converge to 1.
```
